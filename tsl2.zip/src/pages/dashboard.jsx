import React from 'react'

const Dashboard = () => {
  return (
    <div>
    Hello im dashboard  
    </div>
  )
}

export default Dashboard
