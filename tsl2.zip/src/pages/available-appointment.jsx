import React from 'react'

const AvailableAppointment = () => {
  return (
    <div>
      
    </div>
  )
}

export default AvailableAppointment
